def count_in_list(list, target):
    return list.count(target)

